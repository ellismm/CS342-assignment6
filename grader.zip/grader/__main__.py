from . import grader, tests
grader.run()
